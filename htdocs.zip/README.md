<!-- PROJECT LOGO -->
<br />
<p align="center">
  <a href="https://github.com/Alpro2nd/smartend-portal">
    <img src="uploads/settings/14888091199919.png" alt="Logo" width="200" height="60">
  </a>

  <h3 align="center">smartend-portal</h3>

1. First you need to install XAMPP 
2. make sure the php version is 7.3.27
3. open htdocs folder, C:\xampp\htdocs remove or alocate the existing files or folder to other folder. 
4. paste or clone this repo to your htdocs folder
5. run apache and mysql service from your xampp Cpanel.
6. open browser and type http://localhost:8080/phpmyadmin/
7. create new db with the name 'smartend' (without quotation mark)
8. inside the db, import the sql file smartend_db.sql
9. now portal should work, type http://localhost:8080/ in your browser

<hr>

some references :
1. AOS Demo
http://michalsnik.github.io/aos/ 
2. AOS GitHub page
https://github.com/michalsnik/aos

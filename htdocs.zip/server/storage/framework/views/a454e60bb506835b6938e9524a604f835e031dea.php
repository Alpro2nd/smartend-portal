<header>

    <div class="navbar navbar-default">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo e(route("Home")); ?>">
                    <?php if(Helper::GeneralSiteSettings("style_logo_" . trans('backLang.boxCode')) !=""): ?>
                        <img alt=""
                             src="<?php echo e(URL::to('uploads/settings/'.Helper::GeneralSiteSettings("style_logo_" . trans('backLang.boxCode')))); ?>">
                    <?php else: ?>
                        <img alt="" src="<?php echo e(URL::to('uploads/settings/nologo.png')); ?>">
                    <?php endif; ?>

                </a>
            </div>
            <?php echo $__env->make('frontEnd.includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</header>

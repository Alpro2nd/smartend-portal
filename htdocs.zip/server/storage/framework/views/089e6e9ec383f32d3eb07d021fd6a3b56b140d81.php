<div class="col-lg-4">
    <aside class="right-sidebar">
        <div class="widget">
            <?php echo e(Form::open(['route'=>['searchTopics'],'method'=>'POST','class'=>'form-search'])); ?>

            <div class="input-group input-group-sm">
                <?php echo Form::text('search_word',@$search_word, array('placeholder' => trans('frontLang.search'),'class' => 'form-control','id'=>'search_word','required'=>'')); ?>

                <span class="input-group-btn">
                    <button type="submit" class="btn btn-theme"><i class="fa fa-search"></i></button>
                </span>
            </div>

            <?php echo e(Form::close()); ?>

        </div>

        <?php if(count($Categories)>0): ?>
            <?php
            $category_title_var = "title_" . trans('backLang.boxCode');
            $slug_var = "seo_url_slug_" . trans('backLang.boxCode');
            $slug_var2 = "seo_url_slug_" . trans('backLang.boxCodeOther');
            ?>
            <div class="widget">
                <h5 class="widgetheading"><?php echo e(trans('frontLang.categories')); ?></h5>
                <ul class="cat">
                    <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $active_cat = ""; ?>
                        <?php if($CurrentCategory!="none"): ?>
                            <?php if(!empty($CurrentCategory)): ?>
                                <?php if($Category->id == $CurrentCategory->id): ?>
                                    <?php $active_cat = "class=active"; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php
                        $ccount = $category_and_topics_count[$Category->id];
                        if ($Category->$slug_var != "" && Helper::GeneralWebmasterSettings("links_status")) {
                            if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                $Category_link_url = url(trans('backLang.code') . "/" . $Category->$slug_var);
                            } else {
                                $Category_link_url = url($Category->$slug_var);
                            }
                        } else {
                            if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                $Category_link_url = route('FrontendTopicsByCatWithLang', ["lang" => trans('backLang.code'), "section" => $Category->webmasterSection->name, "cat" => $Category->id]);
                            } else {
                                $Category_link_url = route('FrontendTopicsByCat', ["section" => $Category->webmasterSection->name, "cat" => $Category->id]);
                            }
                        }
                        ?>
                        <li>
                            <?php if($Category->icon !=""): ?>
                                <i class="fa <?php echo e($Category->icon); ?>"></i> &nbsp;
                            <?php endif; ?>
                            <a <?php echo e($active_cat); ?> href="<?php echo e($Category_link_url); ?>"><?php echo e($Category->$category_title_var); ?></a><span
                                    class="pull-right">(<?php echo e($ccount); ?>)</span></li>
                        <?php $__currentLoopData = $Category->fatherSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MnuCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $active_cat = ""; ?>
                            <?php if($CurrentCategory!="none"): ?>
                                <?php if(!empty($CurrentCategory)): ?>
                                    <?php if($MnuCategory->id == $CurrentCategory->id): ?>
                                        <?php $active_cat = "class=active"; ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php
                            $ccount = $category_and_topics_count[$MnuCategory->id];
                            if ($MnuCategory->$slug_var != "" && Helper::GeneralWebmasterSettings("links_status")) {
                                if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                    $SubCategory_link_url = url(trans('backLang.code') . "/" . $MnuCategory->$slug_var);
                                } else {
                                    $SubCategory_link_url = url($MnuCategory->$slug_var);
                                }
                            } else {
                                if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                    $SubCategory_link_url = route('FrontendTopicsByCatWithLang', ["lang" => trans('backLang.code'), "section" => $MnuCategory->webmasterSection->name, "cat" => $MnuCategory->id]);
                                } else {
                                    $SubCategory_link_url = route('FrontendTopicsByCat', ["section" => $MnuCategory->webmasterSection->name, "cat" => $MnuCategory->id]);
                                }
                            }
                            ?>
                            <li> &nbsp; &nbsp; &nbsp;
                                <?php if($MnuCategory->icon !=""): ?>
                                    <i class="fa <?php echo e($MnuCategory->icon); ?>"></i> &nbsp;
                                <?php endif; ?>
                                <a <?php echo e($active_cat); ?>  href="<?php echo e($SubCategory_link_url); ?>"><?php echo e($MnuCategory->$category_title_var); ?></a><span
                                        class="pull-right">(<?php echo e($ccount); ?>)</span></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

        <?php endif; ?>
        <?php if(count($TopicsMostViewed)>0): ?>
            <?php
            $side_title_var = "title_" . trans('backLang.boxCode');
            $side_title_var2 = "title_" . trans('backLang.boxCodeOther');
            $slug_var = "seo_url_slug_" . trans('backLang.boxCode');
            $slug_var2 = "seo_url_slug_" . trans('backLang.boxCodeOther');
            ?>
            <div class="widget">
                <h5 class="widgetheading"><?php echo e(trans('frontLang.mostViewed')); ?></h5>
                <ul class="recent">
                    <?php $__currentLoopData = $TopicsMostViewed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TopicMostViewed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        if ($TopicMostViewed->$side_title_var != "") {
                            $side_title = $TopicMostViewed->$side_title_var;
                        } else {
                            $side_title = $TopicMostViewed->$side_title_var2;
                        }
                        if ($TopicMostViewed->$slug_var != "" && Helper::GeneralWebmasterSettings("links_status")) {
                            if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                $topic_link_url = url(trans('backLang.code') . "/" . $TopicMostViewed->$slug_var);
                            } else {
                                $topic_link_url = url($TopicMostViewed->$slug_var);
                            }
                        } else {
                            if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                $topic_link_url = route('FrontendTopicByLang', ["lang" => trans('backLang.code'), "section" => $TopicMostViewed->webmasterSection->name, "id" => $TopicMostViewed->id]);
                            } else {
                                $topic_link_url = route('FrontendTopic', ["section" => $TopicMostViewed->webmasterSection->name, "id" => $TopicMostViewed->id]);
                            }
                        }
                        ?>
                        <li>
                            <div class="row">
                                <div class="col-lg-12">
                                    <a href="<?php echo e($topic_link_url); ?>">
                                        <?php if($TopicMostViewed->photo_file !=""): ?>
                                            <img src="<?php echo e(URL::to('uploads/topics/'.$TopicMostViewed->photo_file)); ?>"
                                                 class="pull-left" alt="<?php echo e($side_title); ?>"/>
                                        <?php elseif($TopicMostViewed->webmasterSection->type==2 && $TopicMostViewed->video_file!=""): ?>
                                            <?php if($Topic->video_type ==1): ?>
                                                <?php
                                                $Youtube_id = Helper::Get_youtube_video_id($Topic->video_file);
                                                ?>
                                                <?php if($Youtube_id !=""): ?>
                                                    <img src="http://img.youtube.com/vi/<?php echo e($Youtube_id); ?>/0.jpg"
                                                         class="pull-left" alt="<?php echo e($side_title); ?>"/>
                                                <?php endif; ?>
                                            <?php elseif($Topic->video_type ==2): ?>
                                                <?php
                                                $Vimeo_id = Helper::Get_vimeo_video_id($Topic->video_file);
                                                ?>
                                                <?php if($Vimeo_id !=""): ?>
                                                    <?php
                                                    $hash = unserialize(file_get_contents("http://vimeo.com/api/v2/video/$Vimeo_id.php"));
                                                    ?>

                                                    <img src="<?php echo e($hash[0]['thumbnail_large']); ?>"
                                                         class="pull-left" alt="<?php echo e($side_title); ?>"/>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </a>
                                    <h6>
                                        <a href="<?php echo e($topic_link_url); ?>"><?php echo e($side_title); ?></a>
                                    </h6>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php
        // View side banners
        $BannersSettingsId = Helper::GeneralWebmasterSettings("side_banners_section_id"); // You can get settings ID from Webmaster >> Banners settings
        ?>
        <?php echo $__env->make('frontEnd.includes.banners', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </aside>
</div>
<!DOCTYPE html>
<html lang="<?php echo e(trans('backLang.code')); ?>" dir="<?php echo e(trans('backLang.direction')); ?>">
<head>
    <?php echo $__env->make('backEnd.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
<div class="app" id="app">

    <!-- ############ LAYOUT START-->
    <div class="center-block w-xxl w-auto-xs p-y-md">
        <div class="navbar">
            <div class="pull-center">
                <div>
                    <a class="navbar-brand"><img src="<?php echo e(URL::to('backEnd/assets/images/logo.png')); ?>" alt="."> <span
                            class="hidden-folded inline"><?php echo e(trans('backLang.control')); ?></span></a>
                </div>
            </div>
        </div>
        <div class="p-a-md box-color r box-shadow-z1 text-color">
            <div class="m-b text-sm">
                <?php echo e(trans('backLang.signedInToControl')); ?>

            </div>
            <form name="form" method="POST" action="<?php echo e(url('/login')); ?>">
                <?php echo e(csrf_field()); ?>

                <?php if($errors ->any()): ?>
                    <div class="alert alert-danger m-b-0">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <div class="md-form-group float-label <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="md-input" required>
                    <label><?php echo e(trans('backLang.connectEmail')); ?></label>
                </div>
                <div class="md-form-group float-label <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <input type="password" name="password" class="md-input" required>
                    <label><?php echo e(trans('backLang.connectPassword')); ?></label>
                </div>
                <?php if($errors->has('password')): ?>
                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                <?php endif; ?>
                <div class="m-b-md">
                    <label class="md-check">
                        <input type="checkbox" name="remember"><i
                            class="primary"></i> <?php echo e(trans('backLang.keepMeSignedIn')); ?>

                    </label>
                </div>
                <button type="submit" class="btn primary btn-block p-x-md m-b"><?php echo e(trans('backLang.signIn')); ?></button>
            </form>
            <hr/>
            <?php if(env("FACEBOOK_STATUS") && env("FACEBOOK_ID") && env("FACEBOOK_SECRET")): ?>
                <a href="<?php echo e(route('social.oauth', 'facebook')); ?>" class="btn btn-primary btn-block text-left">
                    <i class="fa fa-facebook pull-right"></i> <?php echo e(trans('backLang.loginWithFacebook')); ?>

                </a>
            <?php endif; ?>
            <?php if(env("TWITTER_STATUS") && env("TWITTER_ID") && env("TWITTER_SECRET")): ?>
                <a href="<?php echo e(route('social.oauth', 'twitter')); ?>" class="btn btn-info btn-block text-left">
                    <i class="fa  fa-twitter pull-right"></i> <?php echo e(trans('backLang.loginWithTwitter')); ?>

                </a>
            <?php endif; ?>
            <?php if(env("GOOGLE_STATUS") && env("GOOGLE_ID") && env("GOOGLE_SECRET")): ?>
                <a href="<?php echo e(route('social.oauth', 'google')); ?>" class="btn danger btn-block text-left">
                    <i class="fa fa-google pull-right"></i> <?php echo e(trans('backLang.loginWithGoogle')); ?>

                </a>
            <?php endif; ?>
            <?php if(env("LINKEDIN_STATUS") && env("LINKEDIN_ID") && env("LINKEDIN_SECRET")): ?>
                <a href="<?php echo e(route('social.oauth', 'linkedin')); ?>" class="btn btn-primary btn-block text-left">
                    <i class="fa fa-linkedin pull-right"></i> <?php echo e(trans('backLang.loginWithLinkedIn')); ?>

                </a>
            <?php endif; ?>
            <?php if(env("GITHUB_STATUS") && env("GITHUB_ID") && env("GITHUB_SECRET")): ?>
                <a href="<?php echo e(route('social.oauth', 'github')); ?>" class="btn btn-default dark btn-block text-left">
                    <i class="fa fa-github pull-right"></i> <?php echo e(trans('backLang.loginWithGitHub')); ?>

                </a>
            <?php endif; ?>
            <?php if(env("BITBUCKET_STATUS") && env("BITBUCKET_ID") && env("BITBUCKET_SECRET")): ?>
                <a href="<?php echo e(route('social.oauth', 'bitbucket')); ?>" class="btn primary btn-block text-left">
                    <i class="fa fa-bitbucket pull-right"></i> <?php echo e(trans('backLang.loginWithBitbucket')); ?>

                </a>
            <?php endif; ?>

            <?php if(Helper::GeneralWebmasterSettings("register_status")): ?>
                <a href="<?php echo e(url('/register')); ?>" class="btn info btn-block text-left">
                    <i class="fa fa-user-plus pull-right"></i> <?php echo e(trans('backLang.createNewAccount')); ?>

                </a>
            <?php endif; ?>
            <div class="p-v-lg text-center">
                <div class="m-t"><a href="<?php echo e(url('/password/reset')); ?>"
                                    class="text-primary _600"><?php echo e(trans('backLang.forgotPassword')); ?></a></div>
            </div>

        </div>



    </div>

    <!-- ############ LAYOUT END-->


</div>
<?php echo $__env->make('backEnd.includes.foot', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>

